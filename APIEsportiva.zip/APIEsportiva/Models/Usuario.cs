﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace APIEsportiva.Models
{
    public class Usuario : Pessoa
    {
        [JsonProperty("senha")]
        public string Senha { get; set; }

        public override TiposPessoa TipoPessoa
        {
            get
            {
                return TiposPessoa.Usuario;
            }
        }

        public Usuario(long id) : base(id) { }

        public Usuario() : base() { }

        protected override List<string> validarCamposFilhosObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (string.IsNullOrEmpty(Senha))
                camposInvalidos.Add("senha");

            return camposInvalidos;
        }

        protected override string BuscarFilho(BancoDeDados bd)
        {
            if (!ID.HasValue)
                return JsonConvert.SerializeObject(bd.Usuarios.ToList());
            return JsonConvert.SerializeObject(bd.Usuarios.Find(ID));
        }

        protected override void IncluirFilho(BancoDeDados bd)
        {
            bd.Usuarios.Add(this);
            bd.SaveChanges();
            ID = bd.Usuarios.OrderBy(r => r.ID).FirstOrDefault().ID;
        }

        protected override void AtualizarFilho(BancoDeDados bd)
        {
            bd.Usuarios.Update(this);
        }

        protected override void ExcluirFilho(BancoDeDados bd)
        {
            bd.Usuarios.Remove(this);
        }

        public override bool PessoaExiste(BancoDeDados bd)
        {
            return bd.Usuarios.Find(ID) != null;
        }

        public string BuscarSenha()
        {
            using (var bd = BancoDeDados.ConectarNoBanco())
            {
                Usuario user = bd.Usuarios.FirstOrDefault(r => r.Email == Email);
                if (user == null)
                    throw new Exception("Não existe nenhum usuário cadastrado com o email " + Email);
                return user.Senha;
            }
        }

        protected override void Detach(BancoDeDados bd)
        {
            Usuario usauario = bd.Usuarios.Local.FirstOrDefault(r => r.ID == ID);
            if (usauario != null)
                bd.Entry(usauario).State = EntityState.Detached;
            throw new NotImplementedException();
        }
    }
}
