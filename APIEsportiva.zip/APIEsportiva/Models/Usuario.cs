﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace APIEsportiva.Models
{
    public class Usuario : Pessoa
    {
        [JsonProperty("senha")]
        public string Senha { get; set; }

        public override TiposPessoa TipoPessoa
        {
            get
            {
                return TiposPessoa.Usuario;
            }
        }

        public Usuario(long id) : base(id) { }

        public Usuario() : base() { }

        protected override List<string> validarCamposFilhosObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (string.IsNullOrEmpty(Senha))
                camposInvalidos.Add("senha");

            return camposInvalidos;
        }
    }
}
