﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace APIEsportiva.Models
{
    public class Treinador : Pessoa
    {
        [JsonProperty("dataNascimento")]
        public string DataNascimentoString { get; } = "";
        [JsonProperty("esporte")]
        public string Esporte { get; set; } = "";
        [JsonProperty("telefone")]
        public string Telefone { get; set; } = "";
        public DateTime DataNascimento { get; set; }
        public override TiposPessoa TipoPessoa
        {
            get
            {
                return TiposPessoa.Treinador;
            }
        }

        public Treinador(long id) : base(id) { }

        public Treinador() : base() { }

        protected override List<string> validarCamposFilhosObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (string.IsNullOrEmpty(DataNascimentoString))
                camposInvalidos.Add("dataNascimento");

            if (string.IsNullOrEmpty(Esporte))
                camposInvalidos.Add("esporte");

            return camposInvalidos;
        }
    }
}
