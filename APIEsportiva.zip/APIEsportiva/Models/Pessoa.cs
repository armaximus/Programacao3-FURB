﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;

namespace APIEsportiva.Models
{
    public abstract class Pessoa
    {
        public abstract TiposPessoa TipoPessoa { get; }

        public enum TiposPessoa
        {
            Usuario,
            Atleta,
            Treinador
        }

        [JsonProperty("id")]
        public long ID { get; set; }
        [JsonProperty("nome")]
        public string Nome { get; set; }
        [JsonProperty("email")]
        public string Email { get; set; }

        public Pessoa(long id)
        {
            ID = id;
        }

        public Pessoa()
        {
            ID = -1;
        }

        public string Buscar()
        {
            if (ID == -1)
            {
                switch (TipoPessoa)
                {
                    case TiposPessoa.Usuario:
                        return JsonConvert.SerializeObject(Program.BD.Usuarios);
                    case TiposPessoa.Atleta:
                        return JsonConvert.SerializeObject(Program.BD.Atletas);
                    case TiposPessoa.Treinador:
                        return JsonConvert.SerializeObject(Program.BD.Treinadores);
                    default:
                        throw new Exception("Não existe o tipo de pessoa informada!");
                }
            }
            else
            {
                Pessoa pessoa = null;

                switch (TipoPessoa)
                {
                    case TiposPessoa.Usuario:
                        pessoa = Program.BD.Usuarios.Find(ID);
                        break;
                    case TiposPessoa.Atleta:
                        pessoa = Program.BD.Atletas.Find(ID);
                        break;
                    case TiposPessoa.Treinador:
                        pessoa = Program.BD.Treinadores.Find(ID);
                        break;
                    default:
                        throw new Exception("Não existe o tipo de pessoa informada!");
                }

                return JsonConvert.SerializeObject(pessoa);
            }
        }

        public long Incluir()
        {
            validarCampos();

            switch (TipoPessoa)
            {
                case TiposPessoa.Usuario:
                    Program.BD.Usuarios.Add((Usuario)this);
                    return Program.BD.Usuarios.OrderBy(r => r.ID).FirstOrDefault().ID;
                case TiposPessoa.Atleta:
                    if (Program.BD.Usuarios.Find(ID) != null)
                        throw new PessoaExistenteException("O atleta especificado já está cadastrado!");
                    Program.BD.Atletas.Add((Atleta)this);
                    return Program.BD.Atletas.OrderBy(r => r.ID).FirstOrDefault().ID;
                case TiposPessoa.Treinador:
                    if (Program.BD.Usuarios.Find(ID) != null)
                        throw new PessoaExistenteException("O usuário especificado já está cadastrado!");
                    Program.BD.Treinadores.Add((Treinador)this);
                    return Program.BD.Treinadores.OrderBy(r => r.ID).FirstOrDefault().ID;
                default:
                    throw new Exception("Não existe o tipo de pessoa informada!");
            }
        }

        public void Atualizar()
        {
            validarCampos();

            switch (TipoPessoa)
            {
                case TiposPessoa.Usuario:
                    Program.BD.Usuarios.Update((Usuario)this);
                    break;
                case TiposPessoa.Atleta:
                    Program.BD.Atletas.Update((Atleta)this);
                    break;
                case TiposPessoa.Treinador:
                    Program.BD.Treinadores.Update((Treinador)this);
                    break;
                default:
                    throw new Exception("Não existe o tipo de pessoa informada!");
            }
        }

        public void Excluir()
        {
            switch (TipoPessoa)
            {
                case TiposPessoa.Usuario:
                    Program.BD.Usuarios.Remove((Usuario)this);
                    break;
                case TiposPessoa.Atleta:
                    Program.BD.Atletas.Remove((Atleta)this);
                    break;
                case TiposPessoa.Treinador:
                    Program.BD.Treinadores.Remove((Treinador)this);
                    break;
                default:
                    throw new Exception("Não existe o tipo de pessoa informada!");
            }
        }

        private void validarCampos()
        {
            List<string> camposInvalidos = validarCamposObrigatorios();
            if (camposInvalidos.Count > 0)
                throw new Exception($"Os campos {string.Join(", ", camposInvalidos)} não possuem valores válidos/são obrigatórios! Favor revisar o JSON enviado.");
        }

        public List<string> validarCamposObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (ID == -1)
                camposInvalidos.Add("id");

            if (string.IsNullOrEmpty(Nome))
                camposInvalidos.Add("nome");

            camposInvalidos.AddRange(validarCamposFilhosObrigatorios());

            return camposInvalidos;
        }

        protected abstract List<string> validarCamposFilhosObrigatorios();
    }
}
