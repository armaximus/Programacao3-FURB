﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace APIEsportiva.Models
{
    public class Atleta : Pessoa
    {
        [JsonProperty("dataNascimento")]
        public string DataNascimentoString { get; } = "";
        [JsonProperty("altura")]
        public double Altura { get; set; } = 0;
        [JsonProperty("peso")]
        public double Peso { get; set; } = 0;
        [JsonProperty("esporte")]
        public string Esporte { get; set; } = "";
        [JsonProperty("telefone")]
        public string Telefone { get; set; } = "";
        [JsonProperty("treinador")]
        public Treinador Treinador { get; set; } = null;
        public DateTime DataNascimento { get; set; }
        public override TiposPessoa TipoPessoa {
            get
            {
                return TiposPessoa.Atleta;
            }
        }

        public Atleta(long id) : base(id) { }

        public Atleta() : base() { }

        protected override List<string> validarCamposFilhosObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (string.IsNullOrEmpty(DataNascimentoString))
                camposInvalidos.Add("dataNascimento");
            
            if (Altura <= 0 || Altura > 2.58)
                camposInvalidos.Add("altura");
            
            if (Peso < 40 || Peso > 200)
                camposInvalidos.Add("peso");
            
            if (string.IsNullOrEmpty(Esporte))
                camposInvalidos.Add("esporte");
            
            if (Treinador == null)
                camposInvalidos.Add("treinador");

            List<string> camposInvalidosTreinador = Treinador.validarCamposObrigatorios();
            camposInvalidosTreinador.ForEach(r => r = "treinador." + r);
            camposInvalidos.AddRange(camposInvalidosTreinador);

            return camposInvalidos;
        }
    }
}
