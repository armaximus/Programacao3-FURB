﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace APIEsportiva.Models
{
    public class Atleta : Pessoa
    {
        [JsonProperty("dataNascimento")]
        public string DataNascimento { get; set; }

        [JsonProperty("altura")]
        public string Altura { get; set; } 

        [JsonProperty("peso")]
        public string Peso { get; set; }

        [JsonProperty("esporte")]
        public string Esporte { get; set; }

        [JsonProperty("idTreinador")]
        public long? Treinador { get; set; }

        public override TiposPessoa TipoPessoa
        {
            get
            {
                return TiposPessoa.Atleta;
            }
        }

        public Atleta(long id) : base(id) { }

        public Atleta() : base() { }

        protected override List<string> validarCamposFilhosObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (string.IsNullOrEmpty(DataNascimento))
                camposInvalidos.Add("dataNascimento");
            else
            {
                DateTime dataNascimento = new DateTime();
                if (!DateTime.TryParse(DataNascimento, out dataNascimento))
                    camposInvalidos.Add("dataNascimento");
            }

            double altura = 0;
            if (double.TryParse(Altura, out altura))
            {
                if (altura <= 0 || altura > 2.58)
                    camposInvalidos.Add("altura");
            }
            else
                camposInvalidos.Add("altura");

            double peso = 0;
            if (double.TryParse(Peso, out peso))
            {
                if (peso < 40 || peso > 200)
                    camposInvalidos.Add("peso");
            }
            else
                camposInvalidos.Add("peso");

            if (string.IsNullOrEmpty(Esporte))
                camposInvalidos.Add("esporte");
            
            if (!Treinador.HasValue)
                camposInvalidos.Add("treinador");
            else if (Treinador < 1)
                camposInvalidos.Add("treinador");

            return camposInvalidos;
        }

        protected override string BuscarFilho(BancoDeDados bd)
        {
            if (!ID.HasValue)
                return JsonConvert.SerializeObject(bd.Atletas.ToList());
            return JsonConvert.SerializeObject(bd.Atletas.Find(ID));
        }

        protected override void IncluirFilho(BancoDeDados bd)
        {
            Treinador treinador = new Treinador(Treinador.Value);

            if (!treinador.PessoaExiste(bd))
                throw new Exception($"Não existe nenhum {treinador.TipoPessoa.ToString()} de ID {Treinador}");

            bd.Atletas.Add(this);
            bd.SaveChanges();
            ID = bd.Atletas.OrderBy(r => r.ID).FirstOrDefault().ID;
        }

        protected override void AtualizarFilho(BancoDeDados bd)
        {
            bd.Atletas.Update(this);
        }

        protected override void ExcluirFilho(BancoDeDados bd)
        {
            bd.Atletas.Remove(this);
        }

        public override bool PessoaExiste(BancoDeDados bd)
        {
            return  bd.Atletas.FirstOrDefault(r => r.ID == ID) != null;
        }

        protected override void Detach(BancoDeDados bd)
        {
            Atleta atleta = bd.Atletas.Local.FirstOrDefault(r => r.ID == ID);
            if (atleta != null)
                bd.Entry(atleta).State = EntityState.Detached;
        }
    }
}
