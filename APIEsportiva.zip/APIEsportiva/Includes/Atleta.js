﻿
var editando = false;

function mostarPessoas(jsonPessoas) {
    let tabelaDePessoas = document.getElementById('tabelaDeValores');
    let [, , ...resto] = tabelaDePessoas.children;

    resto.forEach(tdAtual => {
        if (tdAtual) {
            tabelaDePessoas.removeChild(tdAtual);
        }
    });

    let propriedadesDoObjeto = ['id', 'nome', 'idTreinador', 'esporte', 'altura', 'peso', 'email'];
    jsonPessoas.forEach(objeto => {
        if (objeto) {
            let linha = document.createElement('tr');

            propriedadesDoObjeto.forEach(propriedade => {
                linha.appendChild(criarElementoTD(objeto[propriedade]))
            });

            let acoesPessoa = document.createElement('td');
            let div = document.createElement('div');
            let separador = document.createElement('label');
            separador.innerText = '|';

            let atleta = new Atleta(objeto.id, objeto.nome, objeto.email, objeto.altura, objeto.peso, objeto.esporte, objeto.idTreinador);

            div.appendChild(criarElementoButton('editar', () => { atleta.buscarAtleta(editaPessoaDeAntemao(atleta.id, atleta)) }));
            div.appendChild(separador);
            div.appendChild(criarElementoButton('excluir', () => { atleta.excluirAtleta(atleta.buscarPessoas()) }));


            acoesPessoa.appendChild(div);
            linha.appendChild(acoesPessoa);

            tabelaDePessoas.appendChild(linha);
        }
    });
}

function criarElementoTD(valorElemento) {
    let elemento = document.createElement('td');
    elemento.innerText = valorElemento;
    return elemento;
}

function criarElementoButton(valorLegenda, funcaoBotao) {
    let botao = document.createElement('input');
    botao.type = 'button';
    botao.value = valorLegenda;
    botao.onclick = () => { funcaoBotao() };
    botao.classList.add('botoesAcoes');

    return botao;
}

function editaPessoaDeAntemao(idatleta, atleta) {

    let novaLegenda = document.getElementById('legendaPessoa');
    novaLegenda.innerText = `Editando dados do Pessoa #${idPessoa}`;

    document.getElementById('nomeFormulario').value = atleta.nome;
    document.getElementById('esporteFormulario').value = atleta.esporte;

    document.getElementById('alturaFormulario').value = atleta.altura;
    document.getElementById('pesoFormulario').value = atleta.peso;
    document.getElementById('idTreinadorFormulario').value = atleta.idTreinador;
    document.getElementById('emailFormulario').value = atleta.email;

    document.getElementById('salvarAlteracao').onclick = () => { editarPessoaExistente(idatleta) };
    editando = true;

    window.scroll(0, 0);

    let atletaJS = new Atleta(0, atleta.nome, atleta.email, atleta.altura, atleta.peso, atleta.esporte, atleta.idTreinador);
    atletaJS.buscarAtletas(mostarPessoas);
}

function criarAtleta() {
    let nome = document.getElementById('nomeFormulario') || '';
    let esporte = document.getElementById('esporteFormulario') || '';
    let altura = document.getElementById('alturaFormulario') || '';
    let peso = document.getElementById('pesoFormulario') || '';
    let idTreinador = document.getElementById('idTreinadorFormulario') || '';
    let email = document.getElementById('emailFormulario') || '';


    let atleta = new Atleta(0, nome, email, altura, peso, esporte, idTreinador);
    atleta.cadastrarAtleta();
}

function editarPessoaExistente(id) {
    let nome = document.getElementById('nomeFormulario') || '';
    let esporte = document.getElementById('esporteFormulario') || '';
    let altura = document.getElementById('alturaFormulario') || '';
    let peso = document.getElementById('pesoFormulario') || '';
    let idTreinador = document.getElementById('idTreinadorFormulario') || '';
    let email = document.getElementById('emailFormulario') || '';

    let atleta = new Atleta(id, nome, email, altura, peso, esporte, idTreinador);
    atleta.editaAtleta();
    //editaPessoa(nome.value, idTreinador?.value, esporte.value, dataNascimento?.value, telefone?.value, altura?.value, peso?.value, email.value);
}

function limparValores() {
    let nome = document.getElementById('nomeFormulario') || '';
    let esporte = document.getElementById('esporteFormulario') || '';
    let altura = document.getElementById('alturaFormulario') || '';
    let peso = document.getElementById('pesoFormulario') || '';
    let idTreinador = document.getElementById('idTreinadorFormulario') || '';
    let email = document.getElementById('emailFormulario') || '';

    nome.value = '';
    esporte.value = '';
    altura.value = '';
    peso.value = '';
    idTreinador.value = '';
    email.value = '';

    if (editando) {
        editando = false;
        document.getElementById('legendaPessoa').innerText = 'Adicionando novo Atleta';
    }
}

let atleta = new Atleta();
atleta.buscarAtletas(mostarPessoas);
