﻿class Pessoa {

    constructor(id, nome, email) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.baseRequestURL = 'https://localhost:44391';
    }

    editaPessoa(config) {
        let requestURL = `${this.baseRequestURL}/${config.name}/atualizar/${this.id}`;
        let request = new XMLHttpRequest();
        request.open('PUT', requestURL);
        request.responseType = 'json';
        request.setRequestHeader('Content-type', 'application/json');

        request.send(config.params);

        request.onload = function () {
            let retorno = request.response;
            if (retorno.status = 'success') {
                alert(`${config.name} editado com sucesso!`);
                buscarPessoas();
            } else {
                alert(`Ocorreu um erro ao tentar editar o ${config.name}! Favor tentar novamente.`);
            }
        }
    }

    cadastrarPessoa(config) {
        let requestURL = `${this.baseRequestURL}/${config.name}`;
        let request = new XMLHttpRequest();
        request.open('POST', requestURL);
        request.responseType = 'json';
        request.setRequestHeader('Content-type', 'application/json');

        request.send(config.params);

        request.onload = function () {
            let retorno = request.response;
            if (retorno.status = 'success') {
                alert(`${config.name} cadastrado com sucesso!`);
                buscarEmpregados();
                limparValores();
            } else {
                alert(`Ocorreu um erro ao tentar cadastrar um ${config.name}! Favor tentar novamente.`);
            }
        }
    }

    excluirPessoa(config) {
        let resposta = confirm(`Deseja excluir o ${config.name} #${this.id}?`);

        if (!resposta) {
            return;
        }

        let requestURL = `${this.baseRequestURL}/${config.name}/excluir/${this.id}`;
        let request = new XMLHttpRequest();
        request.open('DELETE', requestURL);
        request.responseType = 'json';

        request.onload = () => {
            let retorno = request.response;
            if (retorno.status = 'success') {
                alert(`${config.name} excluído com sucesso!`);
                config.callBackFn(); //buscarPessoas();
            } else {
                alert(`Ocorreu um erro ao tentar excluir o ${config.name}! Favor tentar novamente.`);
            }
        }

        request.send();
    }

    buscarPessoas(config) {
        let requestURL = `${this.baseRequestURL}/${config.name}/buscar`;
        let request = new XMLHttpRequest();
        request.open('GET', requestURL);
        request.onload = function () {
            let retorno = request.response;
            config.callBackFn(retorno.data); //mostarPessoas(retorno.data);
        }
        request.responseType = 'json';
        request.send();
    }

    buscarPessoa(config) {
        let requestURL = `${this.baseRequestURL}/${config.name}/buscar/${this.id}`;
        let request = new XMLHttpRequest();
        request.open('GET', requestURL);
        request.onload = function () {
            let retorno = request.response;
            config.callBackFn(retorno.data); //editaPessoaDeAntemao(id, request.response.data);
        }
        request.responseType = 'json';
        request.send()
    }
}

class Atleta extends Pessoa {
    constructor(id, nome, email, altura, peso, esporte, treinador) {
        super(id, nome, email);

        this.altura = altura;
        this.peso = peso;
        this.esporte = esporte;
        this.treinador = treinador;
        this.params = `{ "nome": "${nome}", "treinador": "${treinador}", "esporte": "${esporte}", "altura": "${altura}", "peso": "${peso}", "email": "${email}" }`;
    }

    cadastrarAtleta() {
        this.cadastrarPessoa({ name: 'atleta', params: this.params });
    }

    editaAtleta() {
        this.editaPessoa({ name: 'atleta', params: this.params });
    }

    excluirAtleta(callBackFn) {
        this.excluirPessoa({ name: 'atleta', params: this.params, callBackFn: callBackFn });
    }

    buscarAtletas(callBackFn) {
        this.buscarPessoas({ name: 'atleta', callBackFn: callBackFn });
    }

    buscarAtleta(callBackFn) {
        this.buscarPessoa({ name: 'atleta', callBackFn: callBackFn });
    }
}

class Treinador extends Pessoa {
    constructor(id, nome, email, dataNascimento, esporte, telefone) {
        super(id, nome, email);

        this.dataNascimento = dataNascimento;
        this.esporte = esporte;
        this.telefone = telefone;

        this.params = `{ "nome": "${nome}", "dataNascimento": "${dataNascimento}", "esporte": "${esporte}", "telefone": "${telefone}", "email": "${email}" }`;
    }

    cadastrarTreinador() {
        this.cadastrarPessoa({ name: 'treinador', params: this.params });
    }

    editaTreinador() {
        this.editaPessoa({ name: 'treinador', params: this.params });
    }

    excluirTreinador(callBackFn) {
        this.excluirPessoa({ name: 'treinador', params: this.params, callBackFn: callBackFn });
    }

    buscarTreinadores(callBackFn) {
        this.buscarPessoas({ name: 'treinador', callBackFn: callBackFn });
    }

    buscarTreinador(callBackFn) {
        this.buscarPessoa({ name: 'treinador', callBackFn: callBackFn });
    }
}

class Usuario extends Pessoa {
    constructor(id, nome, email, senha) {
        super(id, nome, email);
        this.senha = senha;

        this.params = `{ "nome": "${nome}", "email": "${email}", "senha": "${senha}" }`;
    }

    cadastrarUsuario() {
        this.cadastrarPessoa({ name: 'usuario', params: this.params });
    }

    editaUsuario() {
        this.editaPessoa({ name: 'usuario', params: this.params });
    }

    excluirUsuario(callBackFn) {
        this.excluirPessoa({ name: 'usuario', params: this.params, callBackFn: callBackFn });
    }

    buscarUsuario(callBackFn) {
        this.buscarPessoas({ name: 'usuario', callBackFn: callBackFn });
    }

    buscarUsuario(callBackFn) {
        this.buscarPessoa({ name: 'usuario', callBackFn: callBackFn });
    }

    buscarSenha(config) {
        let requestURL = `${this.baseRequestURL}/usuario/buscarSenha/${this.email}`;
        let request = new XMLHttpRequest();
        request.open('GET', requestURL);
        request.onload = function () {
            let retorno = request.response;
            config.callBackFn(retorno.data);
        }
        request.responseType = 'json';
        request.send();
    }
}