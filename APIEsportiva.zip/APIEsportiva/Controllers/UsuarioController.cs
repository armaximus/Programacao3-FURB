﻿using System;
using APIEsportiva.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIEsportiva.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UsuarioController : ControllerPai
    {
        protected override void inicializarPessoa(string jsonPessoa = "")
        {
            if (string.IsNullOrEmpty(jsonPessoa))
                Pessoa = new Usuario();
            else
                Pessoa = JsonConvert.DeserializeObject<Usuario>(jsonPessoa);
        }
    }
}
