﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIEsportiva.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace APIEsportiva.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AtletaController : ControllerPai
    {
        protected override void inicializarPessoa(string jsonPessoa = "")
        {
            if (string.IsNullOrEmpty(jsonPessoa))
                Pessoa = new Atleta();
            else
                Pessoa = JsonConvert.DeserializeObject<Atleta>(jsonPessoa);

            Pessoa.ID = null;
        }

        protected override object retornoBusca(string jsonPessoa, bool retornoEmArray)
        {
            if(retornoEmArray)
                return JsonConvert.DeserializeObject<List<Atleta>>(jsonPessoa);
            else
                return JsonConvert.DeserializeObject<Atleta>(jsonPessoa);
        }
    }
}
