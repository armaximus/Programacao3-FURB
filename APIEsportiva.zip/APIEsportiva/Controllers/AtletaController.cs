﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIEsportiva.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace APIEsportiva.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AtletaController : ControllerPai
    {
        protected override void inicializarPessoa(string jsonPessoa = "")
        {
            if (string.IsNullOrEmpty(jsonPessoa))
                Pessoa = new Atleta();
            else
                Pessoa = JsonConvert.DeserializeObject<Atleta>(jsonPessoa);
        }
    }
}
