﻿using APIEsportiva.Models;
using Microsoft.EntityFrameworkCore;

namespace APIEsportiva
{
    public class BancoDeDados : DbContext
    {
        public DbSet<Atleta> Atletas { get; set; }
        public DbSet<Treinador> Treinadores { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlite("Data Source=DataSource.db");
        }
    }
}
