﻿using System;
using System.Collections.Generic;
using APIEsportivaWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIEsportivaWeb.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UsuarioController : ControllerPai
    {
        [HttpGet("buscarSenha/{email}")]
        [Produces("text")]
        public IActionResult BuscarSenha(string email)
        {
            try
            {
                Usuario usuario = new Usuario() { Email = email };
                return Ok(usuario.BuscarSenha());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        protected override void inicializarPessoa(string jsonPessoa = "")
        {
            if (string.IsNullOrEmpty(jsonPessoa))
                Pessoa = new Usuario();
            else
                Pessoa = JsonConvert.DeserializeObject<Usuario>(jsonPessoa);

            Pessoa.ID = null;
        }

        protected override object retornoBusca(string jsonPessoa, bool retornoEmArray)
        {
            if (retornoEmArray)
                return JsonConvert.DeserializeObject<List<Usuario>>(jsonPessoa);
            else
                return JsonConvert.DeserializeObject<Usuario>(jsonPessoa);
        }
    }
}
