class TodasAsFuncionalidades {
    constructor() {
        this.formDeLogin = document.getElementById('formLogin');
        this.motivoFeedback = document.getElementById('motivoFeedback');

        this.legendaLogin = document.getElementById('legendaLogin');
        this.divConfirmarSenha = document.getElementById('divConfirmarSenha');
        this.btnCadastrar = document.getElementById('btnCadastrar');
        this.campoEmail = document.getElementById('campoEmail');
        this.campoSenha = document.getElementById('campoSenha');
        this.campoConfirmarSenha = document.getElementById('campoConfirmarSenha');

        this.camposDentroDoLogin = document.getElementById('identacaoLogin');
        this.divConectado = document.getElementById('divConectado');

        this.conectado = false;
    }


    mostraFormLogin() {
        let ehFlex = this.formDeLogin.style['display'] == 'flex';
        this.formDeLogin.style['display'] = (ehFlex ? 'none' : 'flex');
    }

    funcaoEntrar() {
        if (!this.campoEmail.value) {
            alert('Você deve preencher o campo de Email.');
            return;
        }

        if (!this.campoSenha.value) {
            alert('Você deve preencher o campo senha.');
            return;
        }

        let user = new Usuario(0, '', this.campoEmail.value);
        user.buscarSenha({
            callBackFn: (senha) => {
                if (this.campoSenha.value == senha || JSON.parse(senha) && this.campoSenha.value) {
                    alert('Usuário autenticado com sucesso!');
                } else {
                    alert('Usuário ou senha incorretos.');
                    return;
                }

                for (let i = 0; i < this.camposDentroDoLogin.childElementCount; i++) {
                    this.camposDentroDoLogin.children[i].style.display = 'none';
                }

                sessionStorage.setItem('usuarioLogadoAtletaTreinador', this.campoEmail);

                this.divConectado.style.display = 'inline-flex';
                this.conectado = true;
            }
        });
    }
}