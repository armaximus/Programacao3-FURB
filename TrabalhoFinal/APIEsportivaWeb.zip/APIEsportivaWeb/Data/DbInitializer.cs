﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIEsportivaWeb.Data
{
    public class DbInitializer
    {
        public static void Initialize(BancoDeDados context)
        {
            context.Database.EnsureCreated();
        }
    }
}
