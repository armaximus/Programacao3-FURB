﻿
var editando = false;
const baseRequestURL = ' ';

function mostarPessoas(jsonPessoas) {
    let tabelaDePessoas = document.getElementById('tabelaDeValores');
    let [, , ...resto] = tabelaDePessoas.children;

    resto.forEach(tdAtual => {
        if (tdAtual) {
            tabelaDePessoas.removeChild(tdAtual);
        }
    });

    let propriedadesDoObjeto = ['id', 'nome', 'email', 'dataNascimento', 'esporte', 'telefone'];
    jsonPessoas.forEach(objeto => {
        if (objeto) {
            let linha = document.createElement('tr');

            propriedadesDoObjeto.forEach(propriedade => {
                linha.appendChild(criarElementoTD(objeto[propriedade]))
            });

            let acoesPessoa = document.createElement('td');
            let div = document.createElement('div');
            let separador = document.createElement('label');
            separador.innerText = '|';

            let treinador = new Treinador(objeto.id, objeto.nome, objeto.email, objeto.altura, objeto.peso, objeto.esporte, objeto.idTreinador);

            div.appendChild(criarElementoButton('editar', () => { treinador.buscarTreinador(editaPessoaDeAntemao(treinador.id, treinador)) }));
            div.appendChild(separador);
            div.appendChild(criarElementoButton('excluir', () => { treinador.excluirTreinador(treinador.buscarPessoas()) }));


            acoesPessoa.appendChild(div);
            linha.appendChild(acoesPessoa);

            tabelaDePessoas.appendChild(linha);
        }
    });
}

function criarElementoTD(valorElemento) {
    let elemento = document.createElement('td');
    elemento.innerText = valorElemento;
    return elemento;
}

function criarElementoButton(valorLegenda, funcaoBotao) {
    let botao = document.createElement('input');
    botao.type = 'button';
    botao.value = valorLegenda;
    botao.onclick = () => { funcaoBotao() };
    botao.classList.add('botoesAcoes');

    return botao;
}

function editaPessoaDeAntemao(idTreinador, treinador) {

    let novaLegenda = document.getElementById('legendaPessoa');
    novaLegenda.innerText = `Editando dados do Treinador #${idTreinador} - ${treinador.nome}`;

    document.getElementById('nomeFormulario').value = treinador.nome;
    document.getElementById('esporteFormulario').value = treinador.esporte;
    document.getElementById('dataNascimentoFormulario').value = treinador.dataNascimento;
    document.getElementById('telefoneFormulario').value = treinador.telefone;
    document.getElementById('emailFormulario').value = treinador.email;

    document.getElementById('salvarAlteracao').onclick = () => { editarPessoaExistente(idTreinador) };
    editando = true;

    window.scroll(0, 0);

    let treinadorJS = new Treinador(idTreinador, treinador.nome, treinador.email, treinador.altura, treinador.peso, treinador.esporte, treinador.idTreinador);
    treinadorJS.buscarTreinadores(mostarPessoas);
}

function criarTreinador() {
    let nome = document.getElementById('nomeFormulario') || '';
    let esporte = document.getElementById('esporteFormulario') || '';
    let dataNascimento = document.getElementById('dataNascimentoFormulario') || '';
    let telefone = document.getElementById('telefoneFormulario') || '';
    let email = document.getElementById('emailFormulario') || '';


    let treinador = new Treinador(0, nome?.value, email?.value, dataNascimento?.value, esporte?.value, telefone?.value);
    treinador.cadastrarTreinador();
    treinador.buscarTreinadores(mostarPessoas);
}

function editarPessoaExistente(id) {
    let nome = document.getElementById('nomeFormulario') || '';
    let esporte = document.getElementById('esporteFormulario') || '';
    let dataNascimento = document.getElementById('dataNascimentoFormulario') || '';
    let telefone = document.getElementById('telefoneFormulario') || '';
    let email = document.getElementById('emailFormulario') || '';

    let atleta = new Treinador(id, nome?.value, email?.value, dataNascimento?.value, esporte?.value, telefone?.value);
    atleta.editaAtleta();
    treinador.buscarTreinadores(mostarPessoas);
    //editaPessoa(nome.value, idTreinador?.value, esporte.value, dataNascimento?.value, telefone?.value, altura?.value, peso?.value, email.value);
}

function limparValores() {
    let nome = document.getElementById('nomeFormulario') || '';
    let esporte = document.getElementById('esporteFormulario') || '';
    let dataNascimento = document.getElementById('dataNascimentoFormulario') || '';
    let telefone = document.getElementById('telefoneFormulario') || '';
    let email = document.getElementById('emailFormulario') || '';

    nome.value = '';
    esporte.value = '';
    dataNascimento.value = '';
    telefone.value = '';
    idTreinador.value = '';
    email.value = '';

    if (editando) {
        editando = false;
        document.getElementById('legendaPessoa').innerText = 'Adicionando novo Atleta';
    }
}

let treinador = new Treinador();
treinador.buscarTreinadores(mostarPessoas);
