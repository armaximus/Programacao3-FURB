﻿using System;
using APIEsportivaWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace APIEsportivaWeb.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public abstract class ControllerPai : Controller
    {
        protected Pessoa Pessoa;
        protected abstract void inicializarPessoa(string jsonPessoa = "");

        // GET <UsuariosController>/buscar&
        [HttpGet("buscar")]
        [Produces("application/json")]
        [Authorize]
        public IActionResult Get()
        {
            try
            {
                inicializarPessoa();
                return Ok(retornoBusca(Pessoa.Buscar(), true));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        protected abstract object retornoBusca(string jsonPessoa, bool retornoEmArray);

        // GET <UsuariosController>/buscar/5
        [HttpGet("buscar/{id}")]
        [Produces("application/json")]
        [Authorize]
        public IActionResult Get(int id)
        {
            try
            {
                inicializarPessoa();
                Pessoa.ID = id;
                return Ok(retornoBusca(Pessoa.Buscar(), false));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST <UsuariosController>
        [HttpPost]
        [Produces("application/json")]
        [Authorize]
        public IActionResult Post([FromBody] object value)
        {
            try
            {
                inicializarPessoa(value.ToString());
                long idPessoa = Pessoa.Incluir();
                return Created($"https://localhost:44391/Usuario/Buscar/{idPessoa}", $"{Pessoa.TipoPessoa} de ID {idPessoa} adicionado com sucesso!");
            }
            catch (PessoaExistenteException ex)
            {
                return Conflict(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT <UsuariosController>/5
        [HttpPut("atualizar/{id}")]
        [Produces("application/json")]
        [Authorize]
        public IActionResult Put(int id, [FromBody] object value)
        {
            try
            {
                inicializarPessoa(value.ToString());
                Pessoa.ID = id;
                Pessoa.Atualizar();
                return Ok($"Informações do {Pessoa.TipoPessoa} atualizadas com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE <UsuariosController>/excluir/5
        [HttpDelete("excluir/{id}")]
        [Produces("application/json")]
        [Authorize]
        public IActionResult Delete(int id)
        {
            try
            {
                inicializarPessoa();
                Pessoa.ID = id;
                Pessoa.Excluir();
                return Ok($"{Pessoa.TipoPessoa} excluído com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
