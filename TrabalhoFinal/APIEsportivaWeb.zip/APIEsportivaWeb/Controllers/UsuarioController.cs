﻿using System;
using System.Collections.Generic;
using APIEsportivaWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIEsportivaWeb.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UsuarioController : ControllerPai
    {
        [HttpGet("buscarSenha/{email}")]
        [AllowAnonymous]
        public IActionResult BuscarSenha(string email)
        {
            try
            {
                Usuario usuario = new Usuario() { Email = email };
                return Ok(usuario.BuscarSenha());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST <UsuariosController>
        [HttpPost("login")]
        [AllowAnonymous]
        public IActionResult Login([FromBody] object usuario)
        {
            try
            {
                inicializarPessoa(usuario.ToString());
                Autenticacao aut = new Autenticacao();

                try
                {
                    return Ok(aut.Autenticar((Usuario)Pessoa));
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            catch (PessoaExistenteException ex)
            {
                return Conflict(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        protected override void inicializarPessoa(string jsonPessoa = "")
        {
            if (string.IsNullOrEmpty(jsonPessoa))
                Pessoa = new Usuario();
            else
                Pessoa = JsonConvert.DeserializeObject<Usuario>(jsonPessoa);

            Pessoa.ID = null;
        }

        protected override object retornoBusca(string jsonPessoa, bool retornoEmArray)
        {
            if (retornoEmArray)
                return JsonConvert.DeserializeObject<List<Usuario>>(jsonPessoa);
            else
                return JsonConvert.DeserializeObject<Usuario>(jsonPessoa);
        }
    }
}
