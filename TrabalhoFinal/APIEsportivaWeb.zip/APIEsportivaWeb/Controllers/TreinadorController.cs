﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIEsportivaWeb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace APIEsportivaWeb.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TreinadorController : ControllerPai
    {
        protected override void inicializarPessoa(string jsonPessoa = "")
        {
            if (string.IsNullOrEmpty(jsonPessoa))
                Pessoa = new Treinador();
            else
                Pessoa = JsonConvert.DeserializeObject<Treinador>(jsonPessoa);

            Pessoa.ID = null;
        }

        protected override object retornoBusca(string jsonPessoa, bool retornoEmArray)
        {
            if(retornoEmArray)
                return JsonConvert.DeserializeObject<List<Treinador>>(jsonPessoa);
            else
                return JsonConvert.DeserializeObject<Treinador>(jsonPessoa);
        }
    }
}
