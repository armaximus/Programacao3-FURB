﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace APIEsportivaWeb.Models
{
    public class Treinador : Pessoa
    {
        [JsonProperty("dataNascimento")]
        public string DataNascimento { get; set; }
        [JsonProperty("esporte")]
        public string Esporte { get; set; }
        [JsonProperty("telefone")]
        public string Telefone { get; set; }

        public override TiposPessoa TipoPessoa
        {
            get
            {
                return TiposPessoa.Treinador;
            }
        }

        public Treinador(long id) : base(id) { }

        public Treinador() : base() { }

        protected override List<string> validarCamposFilhosObrigatorios()
        {
            List<string> camposInvalidos = new List<string>();

            if (string.IsNullOrEmpty(DataNascimento))
                camposInvalidos.Add("dataNascimento");
            else
            {
                DateTime dataNascimento = new DateTime();
                if (!DateTime.TryParse(DataNascimento, out dataNascimento))
                    camposInvalidos.Add("dataNascimento");
            }

            if (string.IsNullOrEmpty(Esporte))
                camposInvalidos.Add("esporte");

            return camposInvalidos;
        }

        protected override string BuscarFilho(BancoDeDados bd)
        {
            if (!ID.HasValue)
                return JsonConvert.SerializeObject(bd.Treinadores.ToList());
            return JsonConvert.SerializeObject(bd.Treinadores.Find(ID));
        }

        protected override void IncluirFilho(BancoDeDados bd)
        {
            bd.Treinadores.Add(this);
            bd.SaveChanges();
            ID = bd.Treinadores.ToList().Last().ID;
        }

        protected override void AtualizarFilho(BancoDeDados bd)
        {
            
            bd.Treinadores.Update(this);
        }

        protected override void ExcluirFilho(BancoDeDados bd)
        {
            List<Atleta> atletasLigados = AtletasLigados(bd);
            if (atletasLigados.Count > 0)
                throw new Exception($"Não é possível exlucir o treinador atual pois os seguiintes atletas estão ligados a ele: {string.Join(", ", atletasLigados.Select(r => r.ID))}");

            bd.Treinadores.Remove(this);
        }

        public override bool PessoaExiste(BancoDeDados bd)
        {
            return bd.Treinadores.Find(ID) != null;
        }



        private List<Atleta> AtletasLigados(BancoDeDados bd)
        {
            return bd.Atletas.Where(r => r.Treinador == ID).ToList<Atleta>();
        }

        protected override void Detach(BancoDeDados bd)
        {
            Treinador treinador = bd.Treinadores.Local.FirstOrDefault(r => r.ID == ID);
            if (treinador != null)
                bd.Entry(treinador).State = EntityState.Detached;
        }
    }
}
