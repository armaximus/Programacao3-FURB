﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIEsportivaWeb.Models
{
    public class PessoaExistenteException : Exception
    {
        public PessoaExistenteException(string message) : base(message) { }
    }
}
