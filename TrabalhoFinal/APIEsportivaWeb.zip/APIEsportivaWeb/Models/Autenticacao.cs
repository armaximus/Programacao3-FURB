﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace APIEsportivaWeb.Models
{
    public class Autenticacao
    {
        public const string Secret = "UHSADFUHNaujhf7we31h1wnfd9uhfASFDJGIas9187234";

        public string Autenticar(Usuario usuario)
        {
            using (BancoDeDados bd = BancoDeDados.ConectarNoBanco())
            {
                Usuario user = bd.Usuarios.SingleOrDefault(r => r.Email == usuario.Email && r.Senha == usuario.Senha);

                if (user == null)
                    throw new Exception("Nenhum usuário foi encontrado com o Email e Senha repassados!");

                return GerarToken(user);
            }
        }

        private string GerarToken(Usuario usuarioi)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, usuarioi.ID.ToString())
                }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
