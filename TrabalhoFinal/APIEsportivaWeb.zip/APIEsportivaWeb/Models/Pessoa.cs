﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;

namespace APIEsportivaWeb.Models
{
    public abstract class Pessoa
    {
        public abstract TiposPessoa TipoPessoa { get; }

        [JsonProperty("id")]
        public long? ID { get; set; }

        [JsonProperty("nome")]
        public string Nome { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }
        
        public enum TiposPessoa
        {
            Usuario,
            Atleta,
            Treinador
        }


        public Pessoa(long id)
        {
            ID = id;
        }

        public Pessoa()
        {
            ID = -1;
        }


        public string Buscar()
        {
            using (var bd = BancoDeDados.ConectarNoBanco())
            {
                if (ID > 0 && !PessoaExiste(bd))
                    throw new Exception($"Não existe nenhum {TipoPessoa.ToString()} de ID {ID} cadastrado!");
                return BuscarFilho(bd);
            }
        }

        public long Incluir()
        {
            validarCampos(false);

            using (var bd = BancoDeDados.ConectarNoBanco())
            {
                if (PessoaExiste(bd) && TipoPessoa != TiposPessoa.Usuario)
                    throw new PessoaExistenteException($"O {TipoPessoa.ToString()} já está cadastrado");

                ID = null;

                IncluirFilho(bd);
                return ID.Value;
            }
        }

        public void Atualizar()
        {
            validarCampos();

            using (var bd = BancoDeDados.ConectarNoBanco())
            {
                if (!PessoaExiste(bd))
                    throw new Exception($"Naõ existe nenhum {TipoPessoa.ToString()} de ID {ID} cadastrado!");

                Detach(bd);
                AtualizarFilho(bd);
                bd.SaveChanges();
            }
        }

        public void Excluir()
        {
            using (var bd = BancoDeDados.ConectarNoBanco())
            {
                if (!PessoaExiste(bd))
                    throw new Exception($"Naõ existe nenhum {TipoPessoa.ToString()} de ID {ID} cadastrado!");

                Detach(bd);
                ExcluirFilho(bd);
                bd.SaveChanges();
            }
        }


        protected abstract string BuscarFilho(BancoDeDados bd);

        protected abstract void IncluirFilho(BancoDeDados bd);

        protected abstract void AtualizarFilho(BancoDeDados bd);

        protected abstract void ExcluirFilho(BancoDeDados bd);

        protected abstract void Detach(BancoDeDados bd);

        public abstract bool PessoaExiste(BancoDeDados bd);

        private void validarCampos(bool validarID = true)
        {
            List<string> camposInvalidos = validarCamposObrigatorios(validarID);
            if (camposInvalidos.Count > 0)
                throw new Exception($"Os campos {string.Join(", ", camposInvalidos)} não possuem valores válidos ou são obrigatórios! Favor revisar o JSON enviado.");
        }

        private List<string> validarCamposObrigatorios(bool validarID)
        {
            List<string> camposInvalidos = new List<string>();

            if (validarID && ID < 0)
                camposInvalidos.Add("id");

            if (string.IsNullOrEmpty(Nome))
                camposInvalidos.Add("nome");

            camposInvalidos.AddRange(validarCamposFilhosObrigatorios());

            return camposInvalidos;
        }

        protected abstract List<string> validarCamposFilhosObrigatorios();
    }
}
